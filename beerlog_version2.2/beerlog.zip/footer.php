<html>
<p>compatible in both desktop and mobile phones || 
some images were obtained from google.ca <span class = "footercopyright"></span></p>
</html>