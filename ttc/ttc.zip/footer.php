<footer class = "page-footer" id = "webfoot">
	<div class = "container">
		<a class = "grey-text text-lighten-2">
			<span class = "footercopyright"></span>
		</a>
		<a class = "right white-text text-lighten-2" 
		target = "_blank" 
		href = "https://www.facebook.com/groups/379177148881099/">
			| Facebook page
		</a>
		<a class = "right white-text text-lighten-2" 
		target = "_blank" 
		href = "http://www.ourbeerlog.com">
			OurBeerLog.com | 
		</a>
	</div>
</footer>